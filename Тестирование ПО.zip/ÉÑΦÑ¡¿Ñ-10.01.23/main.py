# импорт необходимых модулей
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

# цепляем driver к Chrome
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

### Тест 1 ###
# получаем главную страницу Википедии
driver.get("https://ru.wikipedia.org/")
# устанавливаем время ожидания страницы 5 секунд
driver.implicitly_wait(5) 
wait = WebDriverWait(driver, 5)
# пока не появится главная страница Википедии 
wait.until(EC.visibility_of_element_located((By.ID, "Добро_пожаловать_в_Википедию,")))
print("Тест 1 пройден")

### Тест 2 ###
# выполняем поиск страницы "Нижний Новгород" 
search = driver.find_element(By.XPATH, '//*[@id="searchInput"]') # находим строку ввода
search.send_keys("Нижний Новгород") # заполняем строку ввода 
driver.find_element(By.XPATH, '//*[@id="searchButton"]').click() # нажимаем кнопку поиска
# проверяем, что поиск нашел корректную страницу
RetURL = "https://ru.wikipedia.org/wiki/%D0%9D%D0%B8%D0%B6%D0%BD%D0%B8%D0%B9_%D0%9D%D0%BE%D0%B2%D0%B3%D0%BE%D1%80%D0%BE%D0%B4"
if driver.current_url == RetURL:
    print("Тест 2 пройден")
else:    
    print("Тест 2 не пройден")

### Тест 3 ###
# выполняем поиск страницы "БлаБлаБла", которой нет в Википедии 
search = driver.find_element(By.XPATH, '//*[@id="searchInput"]') # находим строку ввода
search.send_keys("БлаБлаБла") # заполняем строку ввода 
driver.find_element(By.XPATH, '//*[@id="searchButton"]').click() # нажимаем кнопку поиска
# проверяем, что поиск нашел корректную страницу
if EC.visibility_of_element_located((By.ID, "noarticletext")):
    print("Тест 3 пройден")
else:    
    print("Тест 3 не пройден")

### Тест 4 ###
# выполняем вход по логину и некорректному паролю
driver.find_element(By.XPATH, '//*[@id="pt-login"]/a/span').click()
driver.implicitly_wait(1.5)
# находим поле ввода имени
Username = driver.find_element(By.XPATH, '//*[@id="wpName1"]')
# вводим имя
Username.send_keys("Sasukylov")
# находим поле для пароля
Password = driver.find_element(By.XPATH, '//*[@id="wpPassword1"]')
# вводим неправильный пароль
Password.send_keys("12345678")
# находим и нажимаем кнопку 
driver.find_element(By.XPATH, '//*[@id="wpLoginAttempt"]').click()
# проверяем, что вход не выполнен
if "Введены неверные имя участника или пароль" in driver.page_source: 
    print("Тест 4 пройден")
else:
    print("Тест 4 не пройден")

### Тест 5 ###
# выполняем вход по логину и паролю
driver.find_element(By.XPATH, '//*[@id="pt-login"]/a/span').click()
driver.implicitly_wait(1.5)
# находим поле ввода имени
Username = driver.find_element(By.XPATH, '//*[@id="wpName1"]')
# вводим имя
Username.send_keys("Sasukylov")
# находим поле для пароля
Password = driver.find_element(By.XPATH, '//*[@id="wpPassword1"]')
# вводим пароль
Password.send_keys("+Moodle2022")
# находим и нажимаем кнопку 
driver.find_element(By.XPATH, '//*[@id="wpLoginAttempt"]').click()
# проверяем, что вход выполнен
if "Sasukylov" in driver.page_source:
    print("Тест 5 пройден")
else:
    print("Тест 5 не пройден")

driver.quit()
