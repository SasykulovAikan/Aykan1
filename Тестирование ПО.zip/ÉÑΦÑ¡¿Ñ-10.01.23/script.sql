-- Создание базы данных (если необходимо)
-- CREATE DATABASE shop WITH 
--	OWNER = postgres
--    ENCODING = 'UTF8'
--    CONNECTION LIMIT = -1;

-- Создание схемы в текущей базе данных
CREATE SCHEMA shop;

-- Таблица "Категории продуктов":
-- category_id - уникальный идентификатор,
-- description - описание 
CREATE TABLE shop.category (
    category_id bigserial primary key,
    description text not null
);

-- Таблица "Производители":
-- manufacturer_id - идентификатор,
-- company_name - название,
-- country - страна
CREATE TABLE shop.manufacturer (
    manufacturer_id bigserial primary key,
    company_type varchar(11) not null,
    company_name text,
    country text not null
);
-- создание индекса по названию производителя
CREATE INDEX idx_manufacturer_company_name ON shop.manufacturer(company_name);
-- создание индекса по стране производителя
CREATE INDEX idx_manufacturer_country ON shop.manufacturer(country);

-- Таблица "Продукты":
-- product_id - идентификатор,
-- category_id - категория (идентификатор),
-- manufacturer_id - производитель (идентификатор),
-- description - описание
CREATE TABLE shop.product (
    product_id bigserial primary key,
    category_id bigint not null REFERENCES shop.category (category_id),
    manufacturer_id bigint not null REFERENCES shop.manufacturer (manufacturer_id),
    description text not null
);

-- Проверка для email
CREATE DOMAIN email AS TEXT CHECK (VALUE ~* '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$');

-- Таблица "Поставщики"
-- supplier_id - идентификатор,
-- company_type - тип,
-- company_name - название,
-- inn - ИНН,
-- postcode - почтовый индекс,
-- country - страна,
-- city - город,
-- street - улица,
-- house - дом,
-- phone - номер телефона,
-- email - электронный адрес
CREATE TABLE shop.supplier (
    supplier_id bigserial primary key,
    company_type varchar(11) not null,
    company_name text not null,
    inn varchar(12) UNIQUE not null CHECK (char_length(inn) = 10 or char_length(inn) = 12),
    postcode text,
    country text not null,
    city text not null,
    street text not null,
    house text,
    apartment text,
    phone text UNIQUE not null,
    email email not null
);
-- создание индекса по типу поставщика 
CREATE INDEX idx_supplier_company_type ON shop.supplier(company_type);
-- создание индекса по названию поставщика 
CREATE INDEX idx_supplier_company_name ON shop.supplier(company_name);
-- создание индекса по ИНН поставщика 
CREATE INDEX idx_supplier_inn ON shop.supplier(inn);
-- создание индекса по стране поставщика 
CREATE INDEX idx_supplier_country ON shop.supplier(country);
-- создание индекса по городу поставщика 
CREATE INDEX idx_supplier_city ON shop.supplier(city);
-- создание индекса по номеру телефона поставщика 
CREATE INDEX idx_supplier_phone ON shop.supplier(phone);
-- создание индекса по электронному адрему поставщика 
CREATE INDEX idx_supplier_email ON shop.supplier(email);

-- Таблица "Цены":
-- price_id - идентификатор,
-- product_id продукт (идентификатор),
-- supplier_id - поставщик (идентификатор),
-- price - цена
CREATE TABLE shop.price (
    price_id bigserial primary key,
    product_id bigint not null REFERENCES shop.product (product_id),
    supplier_id bigint not null REFERENCES shop.supplier (supplier_id),
    price numeric not null CHECK (price >= 0)
);

-- Таблица "Покупатели":
-- buyer_id - идентификатор,
-- buyer_name - наименование
CREATE TABLE shop.buyer (
    buyer_id bigserial primary key,
    buyer_name text not null
);


-- Таблица "Счета":
-- invoice_id - идентификатор,
-- buyer_id - покупатель (идентификатор),
-- invoice_number - номер,
-- invoice_date - дата
CREATE TABLE shop.invoice (
    invoice_id bigserial primary key,
    buyer_id bigint not null REFERENCES shop.buyer (buyer_id),
    invoice_number text not null,
    invoice_date timestamp not null
);
-- создание индекса по идентификатору покупателя
CREATE INDEX idx_invoice_buyer_id ON shop.invoice(buyer_id);
-- создание индекса по номеру счета
CREATE INDEX idx_invoice_invoice_number ON shop.invoice(invoice_number);
-- создание индекса по дате счета
CREATE INDEX idx_invoice_invoice_date ON shop.invoice(invoice_date);
-- создание индекса по идентификатору покупателя и номеру счета
CREATE INDEX idx_invoice_buyer_id_invoice_date ON shop.invoice(buyer_id,invoice_date);

-- Таблица "Покупки":
-- sale_id - идентификатор,
-- invoice_id - счет (идентификатор),
-- price_id - цена (идентификатор),
-- amount - количество
CREATE TABLE shop.sale (
    sale_id bigserial primary key,
    invoice_id bigint not null REFERENCES shop.invoice (invoice_id),
    price_id bigint not null REFERENCES shop.price (price_id),
    amount integer not null CHECK (amount > 0)
);

-- создание индекса по по идентификатору цены
CREATE INDEX idx_sale_price_id ON shop.sale(price_id);
-- создание индекса по количеству
CREATE INDEX idx_sale_amount ON shop.sale(amount);